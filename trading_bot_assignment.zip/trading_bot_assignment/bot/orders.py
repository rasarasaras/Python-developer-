
from bot.client import BinanceFuturesClient
from bot.logging_config import setup_logger

logger = setup_logger()

def create_order(symbol, side, order_type, quantity, price=None):
    client = BinanceFuturesClient()

    try:
        logger.info(f"Request -> {symbol} {side} {order_type} Qty:{quantity} Price:{price}")

        response = client.place_order(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price
        )

        logger.info(f"Response -> {response}")

        return response

    except Exception as e:
        logger.error(f"Order failed: {str(e)}")
        raise
