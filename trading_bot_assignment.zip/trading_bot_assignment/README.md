
# Binance Futures Testnet Trading Bot

## Objective
A simplified Python trading bot for Binance Futures Testnet (USDT-M).

## Features
- Place MARKET orders
- Place LIMIT orders
- BUY and SELL support
- CLI-based user input
- Logging and error handling
- Structured project architecture

## Setup

### 1. Clone Repository
```bash
git clone <your-github-link>
cd trading_bot_assignment
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure API Keys
Copy `.env.example` to `.env`

```bash
BINANCE_API_KEY=your_api_key
BINANCE_API_SECRET=your_api_secret
```

## Run Examples

### MARKET BUY Order
```bash
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
```

### LIMIT SELL Order
```bash
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 70000
```

## Logs
Logs are stored inside:
```
logs/bot.log
```

## Assumptions
- Binance Futures Testnet account is already created.
- API keys are valid.
- User has testnet balance.

## Bonus Added
- Enhanced CLI validation
- Structured logging
